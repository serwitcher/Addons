-- Backport of 3.3.5 FrameXML/MathUtil.lua to vanilla 1.12 / Lua 5.0.
--
-- Implementation differences from the 3.3.5 source:
--   - The original wraps CreateCounter's increment in securecallfunction
--     to keep it taint-clean. 1.12 has no taint or secure system, so the
--     wrapper drops to a plain function call.

local ceil = math.ceil
local floor = math.floor
local random = math.random
local atan2 = math.atan2
local sqrt = math.sqrt

MathUtil =
{
	Epsilon = .000001,
};

MathUtil.ApproxZero = MathUtil.Epsilon;
MathUtil.ApproxOne = 1.0 - MathUtil.Epsilon;

function CreateCounter(initialCount, step)
    local count = initialCount or 0
    step = step or 1
    return function()
        count = count + step
        return count
    end
end

function Lerp(startValue, endValue, amount)
    return (1 - amount) * startValue + amount * endValue
end

function Clamp(value, min, max)
    if value > max then
        return max
    elseif value < min then
        return min
    end
    return value
end

function Saturate(value)
    return Clamp(value, 0.0, 1.0)
end

function Wrap(value, max)
    return (value - 1) - floor((value - 1) / max) * max + 1
end

function ClampDegrees(value)
    return ClampMod(value, 360)
end

function ClampMod(value, mod)
    local m = value - floor(value / mod) * mod
    return m - floor(m / mod) * mod
end

function NegateIf(value, condition)
    return condition and -value or value
end

function PercentageBetween(value, startValue, endValue)
    if startValue == endValue then
        return 0.0
    end
    return (value - startValue) / (endValue - startValue)
end

function ClampedPercentageBetween(value, startValue, endValue)
    return Saturate(PercentageBetween(value, startValue, endValue))
end

local TARGET_FRAME_PER_SEC = 60.0
function DeltaLerp(startValue, endValue, amount, timeSec)
    return Lerp(startValue, endValue, Saturate(amount * timeSec * TARGET_FRAME_PER_SEC))
end

function FrameDeltaLerp(startValue, endValue, amount)
    return DeltaLerp(startValue, endValue, amount, GetTickTime())
end

function RandomFloatInRange(minValue, maxValue)
    return Lerp(minValue, maxValue, random())
end

function Round(value)
    if value < 0.0 then
        return ceil(value - .5)
    end
    return floor(value + .5)
end

function RoundToSignificantDigits(value, numDigits)
	local multiplier = 10 ^ numDigits;
	return Round(value * multiplier) / multiplier;
end

-- Rounds the value to to the closest multiple of the passed multiplier
-- Ex: (55, 50) => 50, (85, 50) => 100
function RoundToNearestMultiple(value, multiplier)
	return Round(value / multiplier) * multiplier;
end

function Square(value)
    return value * value
end

function Sign(value)
	return value > 0 and 1 or (value == 0 and 0 or -1);
end

function WithinRange(value, min, max)
	return value >= min and value <= max;
end

function WithinRangeExclusive(value, min, max)
	return value > min and value < max;
end

function ApproximatelyEqual(v1, v2, epsilon)
	return math.abs(v1 - v2) < (epsilon or MathUtil.Epsilon);
end

function CalculateDistanceSq(x1, y1, x2, y2)
    local dx = x2 - x1
    local dy = y2 - y1
    return (dx * dx) + (dy * dy)
end

function CalculateDistance(x1, y1, x2, y2)
    return sqrt(CalculateDistanceSq(x1, y1, x2, y2))
end

function CalculateAngleBetween(x1, y1, x2, y2)
    return atan2(y2 - y1, x2 - x1)
end

AccumulatorMixin = {};

function AccumulatorMixin:Init(initialCount)
	self.count = initialCount or 0;
end

function AccumulatorMixin:Add(count)
	self.count = self.count + count;
	return self.count;
end

function AccumulatorMixin:Subtract(count)
	self.count = self.count - count;
	return self.count;
end

function AccumulatorMixin:Count()
	return self.count;
end

function AccumulatorMixin:Reset(resetCount)
	self.count = resetCount or 0;
end

function CreateAccumulator(initialCount)
	return CreateAndInitFromMixin(AccumulatorMixin, initialCount);
end
