-- Backport of retail's Blizzard_Settings_Shared/Blizzard_SettingControls.lua.
--
-- Differences from the retail source:
--   - No gamepad navigation and no narration: those systems do not exist
--     here, so the mixins do not inherit NarrationSkipTooltipsMixin and the
--     SmartNavigation and Narration calls are gone.
--   - No "new" tags on the elements: nothing in this client is new, so they
--     have no NewFeature label.
--   - No kiosk mode, so an element is always enabled.
--   - Retail's SetScript of OnEnter turns mouse input on; 1.12's does not, so
--     InitDefaultTooltipScriptHandlers turns it on itself.
--   - 1.12's GetChecked returns 1 or nil, so a checkbox reports its value as
--     true or false: a boolean setting takes only a boolean.
--   - 1.12's UIPanelButtonTemplate has no size, so a button control sets the
--     22 pixel height retail's template gives it.
--   - 1.12's OnMouseUp has no upInside argument, so the color swatch row asks
--     whether the mouse is still over it.
--   - 1.12's Button:IsEnabled returns 1 or 0, and 0 is true in Lua, so a row
--     that clicks its checkbox compares the result with 1. Click() toggles a
--     disabled checkbox's check without running its script.

local indentSize = 15;

local function IsButtonEnabled(button)
	return button:IsEnabled() == 1;
end

DefaultTooltipMixin = {};

function DefaultTooltipMixin:InitDefaultTooltipScriptHandlers()
	self:SetScript("OnEnter", self.OnEnter);
	self:SetScript("OnLeave", self.OnLeave);
	self:EnableMouse(true);
end

function DefaultTooltipMixin:OnLoad()
	self:SetDefaultTooltipAnchors();
	self:InitDefaultTooltipScriptHandlers();
end

function DefaultTooltipMixin:SetDefaultTooltipAnchors()
	self.tooltipAnchorParent = nil;
	self.tooltipAnchoring = "ANCHOR_RIGHT";
	self.tooltipXOffset = -10;
	self.tooltipYOffset = 0;
end

function DefaultTooltipMixin:SetTooltipFunc(tooltipFunc)
	self.tooltipFunc = tooltipFunc;
end

function DefaultTooltipMixin:OnEnter()
	if self.tooltipAnchorParent then
		SettingsTooltip:SetOwner(self.tooltipAnchorParent, self.tooltipAnchoring, self.tooltipXOffset, self.tooltipYOffset);
	else
		SettingsTooltip:SetOwner(self, self.tooltipAnchoring, self.tooltipXOffset, self.tooltipYOffset);
	end

	if self.tooltipFunc then
		self.tooltipFunc();
	elseif self.tooltipText then
		SettingsTooltip:SetText(self.tooltipText, nil, nil, nil, nil, true);
	end
	SettingsTooltip:Show();

	if self.HoverBackground then
		self.HoverBackground:Show();
	end
end

function DefaultTooltipMixin:OnLeave()
	SettingsTooltip:Hide();

	if self.HoverBackground then
		self.HoverBackground:Hide();
	end
end

function DefaultTooltipMixin:SetCustomTooltipAnchoring(parent, anchoring, xOffset, yOffset)
	self.tooltipAnchorParent = parent;
	self.tooltipAnchoring = anchoring;
	self.tooltipXOffset = xOffset;
	self.tooltipYOffset = yOffset;
end

local function InitializeSettingTooltip(initializer)
	Settings.InitTooltip(initializer:GetName(), initializer:GetTooltip());
end

SettingsNewTagMixin = { };

function SettingsNewTagMixin:IsNewTagShown()
	if self.data.newTagID then
		return IsNewSettingInCurrentVersion(self.data.newTagID);
	end
end

function SettingsNewTagMixin:MarkSettingAsSeen()
	if self.data.newTagID then
		MarkNewSettingAsSeen(self.data.newTagID);
		return true;
	end
end

SettingsListSectionHeaderMixin = CreateFromMixins(DefaultTooltipMixin, SettingsNewTagMixin);

function SettingsListSectionHeaderMixin:OnLoad()
	DefaultTooltipMixin.OnLoad(self);
	self:RegisterEvent("SETTINGS_HEADER_TEXT_UPDATE");
end

function SettingsListSectionHeaderMixin:OnEvent(event, ...)
	if event == "SETTINGS_HEADER_TEXT_UPDATE" then
		if (self.customNameUpdateFunc) then
			self.Title:SetTextToFit(self.customNameUpdateFunc());
		end
	end
end

function SettingsListSectionHeaderMixin:EvaluateState()
	SettingsListElementMixin.EvaluateState(self);
end

function SettingsListSectionHeaderMixin:Init(initializer)
	local name = initializer:GetName();

	if (initializer.customNameUpdateFunc) then
		self.customNameUpdateFunc = initializer.customNameUpdateFunc;
		name = self.customNameUpdateFunc();
	end

	self.Title:SetTextToFit(name);

	self:SetCustomTooltipAnchoring(self.Title, "ANCHOR_RIGHT");

	self:SetTooltipFunc(GenerateClosure(InitializeSettingTooltip, initializer));
end

function CreateSettingsListSectionHeaderInitializer(name, tooltip, newTagID)
	local data = {name = name, tooltip = tooltip, newTagID = newTagID};
	return Settings.CreateElementInitializer("SettingsListSectionHeaderTemplate", data);
end

SettingsElementHierarchyMixin = {};

-- When adding a parent setting that is informed by children settings, set commit orders so that the parent setting is committed last. See CLASS-35305.
function SettingsElementHierarchyMixin:SetParentInitializer(parentInitializer, modifyPredicate)
	assert(parentInitializer);
	if parentInitializer == self then
		error("SettingsListElementInitializer:SetParentInitializer initializer cannot be self.")
	end

	self.parentInitializer = parentInitializer;

	if modifyPredicate then
		self:AddModifyPredicate(modifyPredicate);
	end
end

function SettingsElementHierarchyMixin:GetParentInitializer()
	return self.parentInitializer;
end

function SettingsElementHierarchyMixin:AddModifyPredicate(func)
	if not self.modifyPredicates then
		self.modifyPredicates = {};
	end
	table.insert(self.modifyPredicates, func);
end

function SettingsElementHierarchyMixin:GetModifyPredicates()
	return self.modifyPredicates;
end

function SettingsElementHierarchyMixin:EvaluateModifyPredicates()
	local prereqs = self:GetModifyPredicates();
	if prereqs then
		for index, prereq in ipairs(prereqs) do
			if not prereq() then
				return false;
			end
		end
	end
	return true;
end

function SettingsElementHierarchyMixin:GetEvaluateStateFrameEvents()
	return self.evaluateStateFrameEvents;
end

function SettingsElementHierarchyMixin:AddEvaluateStateFrameEvent(event)
	if not self.evaluateStateFrameEvents then
		self.evaluateStateFrameEvents = {};
	end
	table.insert(self.evaluateStateFrameEvents, event);
end

function SettingsElementHierarchyMixin:GetEvaluateStateCVars()
	return self.evaluateStateCVars;
end

function SettingsElementHierarchyMixin:AddEvaluateStateCVar(cvar)
	if not self.evaluateStateCVars then
		self.evaluateStateCVars = {};
	end
	table.insert(self.evaluateStateCVars, cvar);
end

SettingsListPanelInitializer = CreateFromMixins(ScrollBoxFactoryInitializerMixin, SettingsSearchableElementMixin, SettingsNewTagMixin);

SettingsListElementInitializer = CreateFromMixins(ScrollBoxFactoryInitializerMixin, SettingsElementHierarchyMixin, SettingsSearchableElementMixin);

function SettingsListElementInitializer:Init(frameTemplate, data)
	ScrollBoxFactoryInitializerMixin.Init(self, frameTemplate);

	self.data = data or {};
end

function SettingsListElementInitializer:Indent()
	self.data.indent = indentSize;
end

function SettingsListElementInitializer:SetKioskProtected()
	self.data.kioskProtected = true;
end

function SettingsListElementInitializer:IsKioskProtected()
	return self.data.kioskProtected;
end

function SettingsListElementInitializer:IsParentInitializerInLayout()
	local parentInitializer = self:GetParentInitializer();
	if not parentInitializer then
		return false;
	end

	local currentLayout = SettingsPanel:GetCurrentLayout();
	if not currentLayout then
		return false;
	end

	for _, initializer in currentLayout:EnumerateInitializers() do
		if initializer == parentInitializer then
			return true;
		end
	end

	return false;
end

function SettingsListElementInitializer:GetIndent()
	return (self.data.indent or self:IsParentInitializerInLayout()) and indentSize or 0;
end

function SettingsListElementInitializer:GetData()
	return self.data;
end

function SettingsListElementInitializer:GetName()
	if self.data.setting then
		return self.data.setting:GetName();
	else
		return self.data.name;
	end
end

function SettingsListElementInitializer:GetTooltip()
	return self.data.tooltip;
end

function SettingsListElementInitializer:GetOptions()
	return self.data.options;
end

function SettingsListElementInitializer:SetSetting(setting)
	self.data.setting = setting;
end

function SettingsListElementInitializer:GetSetting()
	return self.data.setting;
end

function SettingsListElementInitializer:IsNewTagShown()
	local returnVal = SettingsNewTagMixin.IsNewTagShown(self);
	if returnVal == nil then
		local setting = self:GetSetting();
		returnVal = setting and IsNewSettingInCurrentVersion(setting:GetVariable());
	end
	return returnVal;
end

function SettingsListElementInitializer:MarkSettingAsSeen()
	if not SettingsNewTagMixin.MarkSettingAsSeen(self) then
		local setting = self:GetSetting();
		MarkNewSettingAsSeen(setting:GetVariable());
	end
end

function SettingsListElementInitializer:SetSettingIntercept(interceptFunction)
	self.settingIntercept = interceptFunction;
end

function SettingsListElementInitializer:GetSettingIntercept()
	return self.settingIntercept;
end

function SettingsListElementInitializer:SetParentInitializer(parentInitializer, modifyPredicate)
	SettingsElementHierarchyMixin.SetParentInitializer(self, parentInitializer, modifyPredicate);
end

SettingsListElementMixin = {};

function SettingsListElementMixin:OnLoad()
	self.cbrHandles = Settings.CreateCallbackHandleContainer();
end

function SettingsListElementMixin:DisplayEnabled(enabled)
	local color = enabled and NORMAL_FONT_COLOR or GRAY_FONT_COLOR;
	self.Text:SetTextColor(color:GetRGB());
	self:DesaturateHierarchy(enabled and 0 or 1);
end

function SettingsListElementMixin:GetIndent()
	local initializer = self:GetElementData();
	return initializer:GetIndent();
end

function SettingsListElementMixin:SetTooltipFunc(tooltipFunc)
	DefaultTooltipMixin.SetTooltipFunc(self.Tooltip, tooltipFunc);
end

function SettingsListElementMixin:Init(initializer)
	assert(self.cbrHandles:IsEmpty());
	self.data = initializer.data;

	local parentInitializer = initializer:GetParentInitializer();
	if parentInitializer then
		local setting = parentInitializer:GetSetting();
		if setting then
			self.cbrHandles:SetOnValueChangedCallback(setting:GetVariable(), self.OnParentSettingValueChanged, self);
		end
	end

	local evaluateStateFrameEvents = initializer:GetEvaluateStateFrameEvents();
	if evaluateStateFrameEvents then
		for index, event in ipairs(evaluateStateFrameEvents) do
			self.cbrHandles:AddHandle(EventRegistry:RegisterFrameEventAndCallbackWithHandle(event, self.EvaluateState, self));
		end
	end

	local evaluateStateCVars = initializer:GetEvaluateStateCVars();
	if evaluateStateCVars then
		for index, cvar in ipairs(evaluateStateCVars) do
			self.cbrHandles:SetOnValueChangedCallback(cvar, self.EvaluateState, self);
		end
	end

	local font = initializer:IsParentInitializerInLayout() and "GameFontNormalSmall" or "GameFontNormal";
	self.Text:SetFontObject(font);
	self.Text:SetText(initializer:GetName());
	self.Text:SetPoint("LEFT", (self:GetIndent() + 37), 0);
	self.Text:SetPoint("RIGHT", self, "CENTER", -85, 0);

	if initializer.hideText then
		self.Text:Hide();
	end

	self:SetTooltipFunc(GenerateClosure(InitializeSettingTooltip, initializer));
end

function SettingsListElementMixin:Release()
	self.cbrHandles:Unregister();
	self.data = nil;
end

function SettingsListElementMixin:OnSettingValueChanged(setting, value)
end

function SettingsListElementMixin:OnParentSettingValueChanged(setting, value)
	self:EvaluateState();
end

function SettingsListElementMixin:GetSettings()
	return nil;
end

function SettingsListElementMixin:IsEnabled()
	return true;
end

function SettingsListElementMixin:EvaluateState()
	local initializer = self:GetElementData();
	self:SetShown(initializer:ShouldShow());
end

SettingsControlMixin = CreateFromMixins(SettingsListElementMixin);

function SettingsControlMixin:OnLoad()
	SettingsListElementMixin.OnLoad(self);
end

function SettingsControlMixin:Init(initializer)
	SettingsListElementMixin.Init(self, initializer);
	self.cbrHandles:SetOnValueChangedCallback(self:GetSetting():GetVariable(), self.OnSettingValueChanged, self);
end

function SettingsControlMixin:Release()
	SettingsListElementMixin.Release(self);
end

-- Some custom control types have their own settings definitions that may need to be
-- exposed for determining if they have the KioskProtected flag set, so this may be
-- overwritten. However for most control types, this is will only refer a singular
-- setting in the data table.
function SettingsControlMixin:GetSettings()
	local setting = self:GetSetting();
	if setting then
		return {setting};
	end
	return nil;
end

function SettingsControlMixin:GetSetting()
	return self.data.setting;
end

function SettingsControlMixin:SetValue(value)
	-- Implement in derived
end

function SettingsControlMixin:OnSettingValueChanged(setting, value)
	self:SetValue(value);
end

function SettingsControlMixin:IsEnabled()
	local enabled = SettingsListElementMixin.IsEnabled(self);
	if not enabled then
		return false;
	end

	local initializer = self:GetElementData();
	return initializer:EvaluateModifyPredicates();
end

function SettingsControlMixin:ShouldInterceptSetting(value)
	local initializer = self:GetElementData();
	local intercept = initializer:GetSettingIntercept();
	if intercept then
		local result = intercept(value);
		assert(result ~= nil);
		return result;
	end
	return false;
end

SettingsCheckboxMixin = CreateFromMixins(CallbackRegistryMixin, DefaultTooltipMixin);
SettingsCheckboxMixin:GenerateCallbackEvents(
	{
		"OnValueChanged",
	}
);

function SettingsCheckboxMixin:OnLoad()
	CallbackRegistryMixin.OnLoad(self);
	DefaultTooltipMixin.OnLoad(self);
	self.tooltipXOffset = 0;
end

function SettingsCheckboxMixin:Init(value, initTooltip)
	self:SetValue(value);
	self:SetTooltipFunc(initTooltip);

	self:SetScript("OnClick", function(button, buttonName, down)
		self:TriggerEvent(SettingsCheckboxMixin.Event.OnValueChanged, button:GetChecked() and true or false);
	end);
end

function SettingsCheckboxMixin:Release()
	self:SetScript("OnClick", nil);
end

function SettingsCheckboxMixin:SetValue(value)
	self:SetChecked(value);
end

SettingsCheckboxControlMixin = CreateFromMixins(SettingsControlMixin);

function SettingsCheckboxControlMixin:OnLoad()
	SettingsControlMixin.OnLoad(self);

	self.Checkbox = CreateFrame("CheckButton", nil, self, "SettingsCheckboxTemplate");
	self.Checkbox:SetPoint("LEFT", self, "CENTER", -80, 0);

	self.Tooltip:SetScript("OnMouseUp", function()
		if IsButtonEnabled(self.Checkbox) then
			self.Checkbox:Click();
		end
	end);
end

function SettingsCheckboxControlMixin:Init(initializer)
	SettingsControlMixin.Init(self, initializer);

	local setting = self:GetSetting();
	local options = initializer:GetOptions();
	local initTooltip = Settings.CreateOptionsInitTooltip(setting, initializer:GetName(), initializer:GetTooltip(), options);

	self.Checkbox:Init(setting:GetValue(), initTooltip);

	self.cbrHandles:RegisterCallback(self.Checkbox, SettingsCheckboxMixin.Event.OnValueChanged, self.OnCheckboxValueChanged, self);

	self:EvaluateState();
end

function SettingsCheckboxControlMixin:OnSettingValueChanged(setting, value)
	SettingsControlMixin.OnSettingValueChanged(self, setting, value);

	self.Checkbox:SetChecked(value);
end

function SettingsCheckboxControlMixin:OnCheckboxValueChanged(value)
	if self:ShouldInterceptSetting(value) then
		self.Checkbox:SetChecked(not value);
	else
		self:GetSetting():SetValue(value);
	end
end

function SettingsCheckboxControlMixin:SetValue(value)
	self.Checkbox:SetChecked(value);
	if value then
		PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON);
	else
		PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_OFF);
	end
end

function SettingsCheckboxControlMixin:EvaluateState()
	SettingsListElementMixin.EvaluateState(self);
	local enabled = self:IsEnabled();

	local initializer = self:GetElementData();
	local options = initializer:GetOptions();
	if options then
		local optionData = type(options) == 'function' and options() or options;
		local value = self:GetSetting():GetValue();
		for index, option in ipairs(optionData) do
			if option.disabled and option.value ~= value then
				enabled = false;
			end
		end
	end

	self.Checkbox:SetEnabled(enabled);
	self:DisplayEnabled(enabled);
end

function SettingsCheckboxControlMixin:Release()
	self.Checkbox:Release();
	SettingsControlMixin.Release(self);
end

SettingsSliderControlMixin = CreateFromMixins(SettingsControlMixin);

function SettingsSliderControlMixin:OnLoad()
	SettingsControlMixin.OnLoad(self);

	self.SliderWithSteppers = CreateFrame("Frame", nil, self, "MinimalSliderWithSteppersTemplate");
	self.SliderWithSteppers:SetWidth(250);
	self.SliderWithSteppers:SetPoint("LEFT", self, "CENTER", -80, 3);

	Mixin(self.SliderWithSteppers.Slider, DefaultTooltipMixin);

	self.SliderWithSteppers.Slider:InitDefaultTooltipScriptHandlers();
	self.SliderWithSteppers.Slider:SetCustomTooltipAnchoring(self.SliderWithSteppers.Slider, "ANCHOR_RIGHT", 20, 0);
end

function SettingsSliderControlMixin:Init(initializer)
	SettingsControlMixin.Init(self, initializer);

	local setting = self:GetSetting();
	local options = initializer:GetOptions();
	self.SliderWithSteppers:Init(setting:GetValue(), options.minValue, options.maxValue, options.steps, options.formatters);

	self.SliderWithSteppers.Slider:SetTooltipFunc(GenerateClosure(InitializeSettingTooltip, initializer));

	self.cbrHandles:RegisterCallback(self.SliderWithSteppers, MinimalSliderWithSteppersMixin.Event.OnValueChanged, self.OnSliderValueChanged, self);

	self:EvaluateState();
end

function SettingsSliderControlMixin:Release()
	self.SliderWithSteppers:Release();
	SettingsControlMixin.Release(self);
end

function SettingsSliderControlMixin:OnSliderValueChanged(value)
	self:GetSetting():SetValue(value);
end

function SettingsSliderControlMixin:OnSettingValueChanged(setting, value)
	SettingsControlMixin.OnSettingValueChanged(self, setting, value);

	local initializer = self:GetElementData();
	if initializer.reinitializeOnValueChanged then
		self.SliderWithSteppers:FormatValue(self:GetSetting():GetValue());
	end
end

function SettingsSliderControlMixin:SetValue(value)
	self.SliderWithSteppers:SetValue(value);
end

function SettingsSliderControlMixin:EvaluateState()
	SettingsListElementMixin.EvaluateState(self);
	local enabled = self:IsEnabled();
	self.SliderWithSteppers:SetEnabled(enabled);
	self:DisplayEnabled(enabled);
end

SettingsDropdownControlMixin = CreateFromMixins(SettingsControlMixin);

function SettingsDropdownControlMixin:OnLoad()
	SettingsControlMixin.OnLoad(self);

	self:RegisterEvent("SETTINGS_HEADER_TEXT_UPDATE");

	local dropdownType = self.dropdownType or "SettingsDropdownWithButtonsTemplate";
	self.Control = CreateFrame("Frame", nil, self, dropdownType);
	self.Control:SetPoint("LEFT", self, "CENTER", -48, 3);

	self.Control.Dropdown:SetWidth(220);

	local function OnMenuOpen(dropdown)
		local initializer = self:GetElementData();
		if initializer.OnShow then
			initializer.OnShow();
		end
	end

	local function OnMenuClose(dropdown, menu, closeReason)
		local initializer = self:GetElementData();
		if initializer.OnHide then
			initializer.OnHide();
		end
	end

	self.Control.Dropdown:RegisterCallback(DropdownButtonMixin.Event.OnMenuOpen, OnMenuOpen);
	self.Control.Dropdown:RegisterCallback(DropdownButtonMixin.Event.OnMenuClose, OnMenuClose);

	Mixin(self.Control.Dropdown, DefaultTooltipMixin);
end

function SettingsDropdownControlMixin:Init(initializer)
	SettingsControlMixin.Init(self, initializer);

	self:InitDropdown();
	self:EvaluateState();
end

function SettingsDropdownControlMixin:OnEvent(event, ...)
	if event == "SETTINGS_HEADER_TEXT_UPDATE" then
		self.Control.Dropdown:SetSelectionText(self.getSelectionTextFunc);
		self.Control.Dropdown:UpdateToMenuSelections(self.Control.Dropdown:GetMenuDescription());
	end
end

function SettingsDropdownControlMixin:InitDropdown()
	local setting = self:GetSetting();
	local initializer = self:GetElementData();
	local options = initializer:GetOptions();
	local initTooltip = Settings.CreateOptionsInitTooltip(setting, initializer:GetName(), initializer:GetTooltip(), options, initializer);
	self:SetupDropdownMenu(self.Control.Dropdown, setting, options, initTooltip, initializer);

	local forceSteppersHidden = self.forceSteppersHidden or (initializer.data and initializer.data.forceSteppersHidden);
	if forceSteppersHidden then
		self.Control:HideSteppers();
	else
		local hasOnlyRadioDescriptions = self.Control.Dropdown:HasOnlyRadioDescriptions();
		self.Control:SetSteppersShown(hasOnlyRadioDescriptions);
	end

	self.Control.Dropdown:SetSelectionText(initializer.getSelectionTextFunc);
	self.Control.Dropdown:UpdateToMenuSelections(self.Control.Dropdown:GetMenuDescription());
end

function SettingsDropdownControlMixin:SetupDropdownMenu(button, setting, options, initTooltip, initializer)
	local inserter = Settings.CreateDropdownOptionInserter(setting, options, initializer);
	Settings.InitDropdown(self.Control.Dropdown, setting, inserter, initTooltip, initializer);
end

function SettingsDropdownControlMixin:Release()
	SettingsControlMixin.Release(self);
end

function SettingsDropdownControlMixin:OnSettingValueChanged(setting, value)
	SettingsControlMixin.OnSettingValueChanged(self, setting, value);

	local initializer = self:GetElementData();
	if initializer.reinitializeOnValueChanged then
		self:InitDropdown();
	end
end

function SettingsDropdownControlMixin:SetValue(value)
	self:InitDropdown();
end

function SettingsDropdownControlMixin:EvaluateState()
	SettingsListElementMixin.EvaluateState(self);
	local enabled = self:IsEnabled();
	self.Control:SetEnabled(enabled);

	self:DisplayEnabled(enabled);
	return enabled;
end

SettingsButtonControlMixin = CreateFromMixins(SettingsListElementMixin, SettingsNewTagMixin);

function SettingsButtonControlMixin:OnLoad()
	SettingsListElementMixin.OnLoad(self);

	self.Button = CreateFrame("Button", nil, self, "UIPanelButtonTemplate");
	self.Button:SetWidth(200, 26);
	self.Button:SetHeight(22);

	Mixin(self.Button, DefaultTooltipMixin);
	DefaultTooltipMixin.OnLoad(self.Button);
end

function SettingsButtonControlMixin:EvaluateName()
	if type(self.data.buttonText) == "function" then
		return self.data.buttonText();
	end

	return self.data.buttonText;
end

function SettingsButtonControlMixin:Init(initializer)
	SettingsListElementMixin.Init(self, initializer);

	if self.data.gameDataFunc then
		local function OnGameEvent()
			self.data.gameDataFunc(self.Button);
		end
		self.cbrHandles:AddHandle(EventRegistry:RegisterFrameEventAndCallbackWithHandle(self.data.gameDataEvent, OnGameEvent, self));
	end

	self.Button:SetText(self:EvaluateName());
	self.Button:SetScript("OnClick", self.data.buttonClick);
	self.Button:SetTooltipFunc(GenerateClosure(InitializeSettingTooltip, initializer));

	local alignment = "LEFT";
	if self.data.buttonAlignment and self.data.buttonAlignment ~= "" then
		alignment = self.data.buttonAlignment;
	end
	local name = initializer:GetName();
	if alignment == "CENTER" then
		self.Button:SetPoint("CENTER", self, "CENTER", 0, 0);
		self.Tooltip:Hide();
	elseif alignment == "RIGHT" then
		self.Button:SetPoint("RIGHT", self, "RIGHT", -10, 0);
		self.Tooltip:Hide();
	elseif name == "" then
		self.Button:SetPoint("LEFT", self.Text, "LEFT", 0, 0);
		self.Tooltip:Hide();
	else
		self.Button:SetPoint("LEFT", self, "CENTER", -40, 0);
		self.Tooltip:Show();
	end

	self:EvaluateState();
end

function SettingsButtonControlMixin:Release()
	self.cbrHandles:Unregister();
	self.Button:SetScript("OnClick", nil);
	SettingsListElementMixin.Release(self);
end

function SettingsButtonControlMixin:SetButtonState(enabled)
	self.Button:SetEnabled(enabled);
end

function SettingsButtonControlMixin:EvaluateState()
	SettingsListElementMixin.EvaluateState(self);
	local displayEnabled = self:IsEnabled();
	local buttonEnabled = displayEnabled;

	local initializer = self:GetElementData();
	if initializer and not initializer:EvaluateModifyPredicates() then
		buttonEnabled = false;
	end

	self:SetButtonState(buttonEnabled);
	self:DisplayEnabled(displayEnabled);
end

function CreateSettingsButtonInitializer(name, buttonText, buttonClick, tooltip, addSearchTags, newTagID, gameDataFunc, gameDataEvent)
	local data = {name = name, buttonText = buttonText, buttonClick = buttonClick, tooltip = tooltip, newTagID = newTagID, gameDataFunc = gameDataFunc, gameDataEvent = gameDataEvent};
	local initializer = Settings.CreateElementInitializer("SettingButtonControlTemplate", data);

	-- Some settings buttons, like ones that open to a setting category, should not show up in search.
	assert(addSearchTags ~= nil);
	if addSearchTags then
		initializer:AddSearchTags(name);
		initializer:AddSearchTags(buttonText);
	end

	return initializer;
end

SettingsColorSwatchMixin = CreateFromMixins(CallbackRegistryMixin, DefaultTooltipMixin, ColorSwatchMixin);
SettingsColorSwatchMixin:GenerateCallbackEvents(
	{
		"OnValueChanged",
	}
);

function SettingsColorSwatchMixin:OnLoad()
	CallbackRegistryMixin.OnLoad(self);
	DefaultTooltipMixin.OnLoad(self);
	self.tooltipXOffset = 0;
end

function SettingsColorSwatchMixin:Init(value, initTooltip, initialSwatchColorFn)
	self:SetValue(value);
	self:SetTooltipFunc(initTooltip);

	local cachedColor = CreateColor(0, 0, 0, 0); -- Making this here to avoid churn
	local function GetColorString(r, g, b)
		cachedColor:SetRGB(r, g, b);
		return cachedColor:GenerateHexColor();
	end

	local function OnSwatchClick(swatch, button, isDown)
		local info = {};
		info.swatch = swatch;

		local color = initialSwatchColorFn();
		info.r, info.g, info.b = color:GetRGB();

		info.swatchFunc = function()
			self:TriggerEvent(SettingsColorSwatchMixin.Event.OnValueChanged, GetColorString(ColorPickerFrame:GetColorRGB()));
		end;

		info.cancelFunc = function()
			self:TriggerEvent(SettingsColorSwatchMixin.Event.OnValueChanged, GetColorString(ColorPickerFrame:GetPreviousValues()));
		end;

		ColorPickerFrame:SetupColorPickerAndShow(info);
	end

	self:SetScript("OnClick", OnSwatchClick);
	self:SetValue(value);
end

function SettingsColorSwatchMixin:Release()
	self:SetScript("OnClick", nil);
end

function SettingsColorSwatchMixin:SetValue(value)
	self:SetColorValue(CreateColorFromHexString(value));
end

function SettingsColorSwatchMixin:SetColorValue(color)
	self:SetColor(color);
end

function SettingsColorSwatchMixin:OnEnter()
	DefaultTooltipMixin.OnEnter(self);
	ColorSwatchMixin.OnEnter(self);
end

function SettingsColorSwatchMixin:OnLeave()
	DefaultTooltipMixin.OnLeave(self);
	ColorSwatchMixin.OnLeave(self);
end

SettingsColorSwatchControlMixin = CreateFromMixins(SettingsControlMixin);

function SettingsColorSwatchControlMixin:OnLoad()
	SettingsControlMixin.OnLoad(self);

	self.ColorSwatch = CreateFrame("Button", nil, self, "SettingsColorSwatchTemplate");
	self.ColorSwatch:SetPoint("LEFT", self, "CENTER", -73, 0);
end

function SettingsColorSwatchControlMixin:Init(initializer)
	SettingsControlMixin.Init(self, initializer);

	local setting = self:GetSetting();
	local initTooltip = GenerateClosure(InitializeSettingTooltip, initializer);

	local function GetSwatchColor()
		local colorString = setting:GetValue();
		return CreateColorFromHexString(colorString);
	end

	self.ColorSwatch:Init(setting:GetValue(), initTooltip, GetSwatchColor);
	self.cbrHandles:RegisterCallback(self.ColorSwatch, SettingsColorSwatchMixin.Event.OnValueChanged, self.OnSwatchValueChanged, self);

	self.Tooltip:SetScript("OnMouseUp", function(_tooltip, button)
		if button == "LeftButton" and _tooltip:IsMouseOver() then
			self.ColorSwatch:Click();
		end
	end);

	self:EvaluateState();
end

function SettingsColorSwatchControlMixin:OnSwatchValueChanged(value)
	self:GetSetting():SetValue(value);
end

function SettingsColorSwatchControlMixin:Release()
	self.ColorSwatch:Release();
	SettingsControlMixin.Release(self);
end

function SettingsColorSwatchControlMixin:SetButtonState(_enabled)
	-- TODO: Is there a visual state on color swatches for enabled/disabled?
	-- Not yet...
	-- self.ColorSwatch:SetEnabled(enabled);
end

function SettingsColorSwatchControlMixin:OnSettingValueChanged(setting, value)
	SettingsControlMixin.OnSettingValueChanged(self, setting, value);
	self:EvaluateState();
end

function SettingsColorSwatchControlMixin:SetValue(value)
	self.ColorSwatch:SetValue(value);
end

function SettingsColorSwatchControlMixin:EvaluateState()
	SettingsListElementMixin.EvaluateState(self);
	local enabled = self:IsEnabled();
	self:SetButtonState(enabled);
	self:DisplayEnabled(enabled);
end

SettingsCheckboxWithButtonControlMixin = CreateFromMixins(SettingsControlMixin);

function SettingsCheckboxWithButtonControlMixin:OnLoad()
	SettingsControlMixin.OnLoad(self);

	self.Checkbox = CreateFrame("CheckButton", nil, self, "SettingsCheckboxTemplate");
	self.Checkbox:SetPoint("LEFT", self, "CENTER", -80, 0);

	self.Button = CreateFrame("Button", nil, self, "UIPanelButtonTemplate");
	self.Button:SetWidth(200, 26);
	self.Button:SetHeight(22);
	self.Button:SetPoint("LEFT", self.Checkbox, "RIGHT", 5, 0);

	self.Tooltip:SetScript("OnMouseUp", function()
		if IsButtonEnabled(self.Checkbox) then
			self.Checkbox:Click();
		end
	end);
end

function SettingsCheckboxWithButtonControlMixin:Init(initializer)
	SettingsControlMixin.Init(self, initializer);

	local setting = self:GetSetting();
	local initTooltip = GenerateClosure(InitializeSettingTooltip, initializer);

	self.Checkbox:Init(setting:GetValue(), initTooltip);
	self.cbrHandles:RegisterCallback(self.Checkbox, SettingsCheckboxMixin.Event.OnValueChanged, self.OnCheckboxValueChanged, self);

	self.Button:SetText(self:EvaluateName(self.data.buttonText));
	self.Button:SetScript("OnClick", self.data.OnButtonClick);

	self:EvaluateState();
end

function SettingsCheckboxWithButtonControlMixin:OnCheckboxValueChanged(value)
	if value then
		PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON);
	else
		PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_OFF);
	end

	self:GetSetting():SetValue(value);
end

function SettingsCheckboxWithButtonControlMixin:Release()
	self.Checkbox:Release();
	self.Button:SetScript("OnClick", nil);
	SettingsControlMixin.Release(self);
end

function SettingsCheckboxWithButtonControlMixin:SetButtonState(enabled)
	self.Button:SetEnabled(enabled);
end

function SettingsCheckboxWithButtonControlMixin:OnSettingValueChanged(setting, value)
	SettingsControlMixin.OnSettingValueChanged(self, setting, value);

	self:EvaluateState();
end

function SettingsCheckboxWithButtonControlMixin:SetValue(value)
	self.Checkbox:SetChecked(value);
	if value then
		PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON);
	else
		PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_OFF);
	end
end

function SettingsCheckboxWithButtonControlMixin:EvaluateName()
	if type(self.data.buttonText) == "function" then
		return self.data.buttonText();
	end

	return self.data.buttonText;
end

function SettingsCheckboxWithButtonControlMixin:EvaluateState()
	SettingsListElementMixin.EvaluateState(self);
	local enabled = self:IsEnabled();

	-- User provided callback
	if (self.data.OnEvaluateState ~= nil) then
		self.data.OnEvaluateState(self);
	end

	local clickEnabled = enabled;
	if self.data.clickRequiresSet and not self:GetSetting():GetValue() then
		clickEnabled = false;
	end

	self.Button:SetText(self:EvaluateName())
	self:SetButtonState(clickEnabled);
	self:DisplayEnabled(enabled);
end

function CreateSettingsCheckboxWithButtonInitializer(setting, buttonText, buttonClick, evaluateState, clickRequiresSet, tooltip)
	local data = Settings.CreateSettingInitializerData(setting, nil, tooltip);
	data.buttonText = buttonText;
	data.OnButtonClick = buttonClick;
	data.OnEvaluateState = evaluateState;
	data.clickRequiresSet = clickRequiresSet;

	local initializer = Settings.CreateSettingInitializer("SettingsCheckboxWithButtonControlTemplate", data);
	initializer:AddSearchTags(buttonText);

	return initializer;
end

SettingsCheckboxSliderControlMixin = CreateFromMixins(SettingsListElementMixin);

function SettingsCheckboxSliderControlMixin:OnLoad()
	SettingsListElementMixin.OnLoad(self);

	self.Checkbox = CreateFrame("CheckButton", nil, self, "SettingsCheckboxTemplate");
	self.Checkbox:SetPoint("LEFT", self, "CENTER", -80, 0);

	self.SliderWithSteppers = CreateFrame("Frame", nil, self, "MinimalSliderWithSteppersTemplate");
	self.SliderWithSteppers:SetWidth(214);
	self.SliderWithSteppers:SetPoint("LEFT", self.Checkbox, "RIGHT", 5, 0);

	Mixin(self.SliderWithSteppers.Slider, DefaultTooltipMixin);

	self.SliderWithSteppers.Slider:InitDefaultTooltipScriptHandlers();
	self.SliderWithSteppers.Slider:SetCustomTooltipAnchoring(self.SliderWithSteppers.Slider, "ANCHOR_RIGHT", 20, 0);

	self.Tooltip:SetScript("OnMouseUp", function()
		if IsButtonEnabled(self.Checkbox) then
			self.Checkbox:Click();
		end
	end);
end

function SettingsCheckboxSliderControlMixin:Init(initializer)
	SettingsListElementMixin.Init(self, initializer);

	local cbSetting = initializer.data.cbSetting;
	local cbLabel = initializer.data.cbLabel;
	local cbTooltip = initializer.data.cbTooltip;
	local sliderSetting = initializer.data.sliderSetting;
	local sliderOptions = initializer.data.sliderOptions;
	local sliderLabel = initializer.data.sliderLabel;
	local sliderTooltip = initializer.data.sliderTooltip;

	local cbInitTooltip = GenerateClosure(Settings.InitTooltip, cbLabel, cbTooltip);
	self:SetTooltipFunc(cbInitTooltip);

	self.Checkbox:Init(cbSetting:GetValue(), cbInitTooltip);
	self.cbrHandles:RegisterCallback(self.Checkbox, SettingsCheckboxMixin.Event.OnValueChanged, self.OnCheckboxValueChanged, self);

	self.SliderWithSteppers.Slider:SetTooltipFunc(GenerateClosure(Settings.InitTooltip, sliderLabel, sliderTooltip));

	self.SliderWithSteppers:Init(sliderSetting:GetValue(), sliderOptions.minValue, sliderOptions.maxValue, sliderOptions.steps, sliderOptions.formatters);
	self.cbrHandles:RegisterCallback(self.SliderWithSteppers, MinimalSliderWithSteppersMixin.Event.OnValueChanged, self.OnSliderValueChanged, self);

	-- Defaults...
	local function OnCheckboxSettingValueChanged(o, setting, value)
		self.Checkbox:SetValue(value);
		self:EvaluateState();
	end
	self.cbrHandles:SetOnValueChangedCallback(cbSetting:GetVariable(), OnCheckboxSettingValueChanged);

	local function OnSliderSettingValueChanged(o, setting, value)
		self.SliderWithSteppers:SetValue(value);
	end
	self.cbrHandles:SetOnValueChangedCallback(sliderSetting:GetVariable(), OnSliderSettingValueChanged);

	self:EvaluateState();
end

function SettingsCheckboxSliderControlMixin:GetSettings()
	local initializer = self:GetElementData();
	local cbSetting = initializer.data.cbSetting;
	local sliderSetting = initializer.data.sliderSetting;
	return {cbSetting, sliderSetting};
end

function SettingsCheckboxSliderControlMixin:OnCheckboxValueChanged(value)
	local initializer = self:GetElementData();
	local cbSetting = initializer.data.cbSetting;
	cbSetting:SetValue(value);
	if value then
		PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON);
	else
		PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_OFF);
	end

	self:EvaluateState();
end

function SettingsCheckboxSliderControlMixin:OnSliderValueChanged(value)
	local initializer = self:GetElementData();
	local sliderSetting = initializer.data.sliderSetting;
	sliderSetting:SetValue(value);
end

function SettingsCheckboxSliderControlMixin:EvaluateState()
	SettingsListElementMixin.EvaluateState(self);
	local enabled = self:IsEnabled();

	self.Checkbox:SetEnabled(enabled);
	self.SliderWithSteppers:SetEnabled(enabled and self.Checkbox:GetChecked());
	self:DisplayEnabled(enabled);
end

function SettingsCheckboxSliderControlMixin:Release()
	self.Checkbox:Release();
	self.SliderWithSteppers:Release();
	SettingsListElementMixin.Release(self);
end

function CreateSettingsCheckboxSliderInitializer(cbSetting, cbLabel, cbTooltip, sliderSetting, sliderOptions, sliderLabel, sliderTooltip, newTagID)
	local data =
	{
		name = cbLabel,
		tooltip = cbTooltip,
		cbSetting = cbSetting,
		cbLabel = cbLabel,
		cbTooltip = cbTooltip,
		sliderSetting = sliderSetting,
		sliderOptions = sliderOptions,
		sliderLabel = sliderLabel,
		sliderTooltip = sliderTooltip,
		newTagID = newTagID,
	};
	local initializer = Settings.CreateSettingInitializer("SettingsCheckboxSliderControlTemplate", data);
	initializer:AddSearchTags(cbLabel, sliderLabel);
	return initializer;
end

SettingsCheckboxDropdownControlMixin = CreateFromMixins(SettingsListElementMixin);

function SettingsCheckboxDropdownControlMixin:OnLoad()
	SettingsListElementMixin.OnLoad(self);

	self.Checkbox = CreateFrame("CheckButton", nil, self, "SettingsCheckboxTemplate");
	self.Checkbox:SetPoint("LEFT", self, "CENTER", -80, 0);

	self.Control = CreateFrame("Frame", nil, self, "SettingsDropdownWithButtonsTemplate");
	self.Control:SetPoint("LEFT", self.Checkbox, "RIGHT", 32, 0);
	self.Control.Dropdown:SetWidth(220);

	Mixin(self.Control.Dropdown, DefaultTooltipMixin);

	self.Tooltip:SetScript("OnMouseUp", function()
		if IsButtonEnabled(self.Checkbox) then
			self.Checkbox:Click();
		end
	end);
end

function SettingsCheckboxDropdownControlMixin:Init(initializer)
	SettingsListElementMixin.Init(self, initializer);

	local cbSetting = initializer.data.cbSetting;
	local cbLabel = initializer.data.cbLabel;
	local cbTooltip = initializer.data.cbTooltip;
	local dropdownSetting = initializer.data.dropdownSetting;
	local dropdownOptions = initializer.data.dropdownOptions;
	local dropDownLabel = initializer.data.dropDownLabel;
	local dropDownTooltip = initializer.data.dropDownTooltip;

	local initCheckboxTooltip = GenerateClosure(Settings.InitTooltip, cbLabel, cbTooltip);
	self:SetTooltipFunc(initCheckboxTooltip);

	self.Checkbox:Init(cbSetting:GetValue(), initCheckboxTooltip);
	self.cbrHandles:RegisterCallback(self.Checkbox, SettingsCheckboxMixin.Event.OnValueChanged, self.OnCheckboxValueChanged, self);

	local inserter = Settings.CreateDropdownOptionInserter(dropdownSetting, dropdownOptions, initializer);
	local initDropdownTooltip = Settings.CreateOptionsInitTooltip(dropdownSetting, initializer:GetName(), initializer:GetTooltip(), dropdownOptions);
	Settings.InitDropdown(self.Control.Dropdown, dropdownSetting, inserter, initDropdownTooltip);

	local function OnCheckboxSettingValueChanged(o, setting, value)
		self.Checkbox:SetValue(value);
		self:EvaluateState();
	end
	self.cbrHandles:SetOnValueChangedCallback(cbSetting:GetVariable(), OnCheckboxSettingValueChanged);

	local function OnDropdownSettingChanged()
		self:EvaluateState();
	end

	self.cbrHandles:SetOnValueChangedCallback(dropdownSetting:GetVariable(), OnDropdownSettingChanged);

	self.Control.Dropdown:SetSelectionText(initializer.getSelectionTextFunc);
	self.Control.Dropdown:UpdateToMenuSelections(self.Control.Dropdown:GetMenuDescription());

	local hasOnlyRadioDescriptions = self.Control.Dropdown:HasOnlyRadioDescriptions();
	self.Control:SetSteppersShown(hasOnlyRadioDescriptions);

	self:EvaluateState();
end

function SettingsCheckboxDropdownControlMixin:GetSettings()
	local initializer = self:GetElementData();
	local cbSetting = initializer.data.cbSetting;
	local dropdownSetting = initializer.data.dropdownSetting;
	return {cbSetting, dropdownSetting};
end

function SettingsCheckboxDropdownControlMixin:OnCheckboxValueChanged(value)
	local initializer = self:GetElementData();
	local cbSetting = initializer.data.cbSetting;
	cbSetting:SetValue(value);
	if value then
		PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON);
	else
		PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_OFF);
	end

	self:EvaluateState();
end

function SettingsCheckboxDropdownControlMixin:Release()
	self.Checkbox:Release();
	SettingsListElementMixin.Release(self);
end

function SettingsCheckboxDropdownControlMixin:IsEnabled()
	local enabled = SettingsListElementMixin.IsEnabled(self);
	if not enabled then
		return false;
	end

	local initializer = self:GetElementData();
	return initializer:EvaluateModifyPredicates();
end

function SettingsCheckboxDropdownControlMixin:EvaluateState()
	SettingsListElementMixin.EvaluateState(self);
	local enabled = self:IsEnabled();

	self.Checkbox:SetEnabled(enabled);
	self.Control.Dropdown:SetEnabled(enabled and self.Checkbox:GetChecked());
	self.Control:UpdateSteppers();
	self:DisplayEnabled(enabled);
end

function CreateSettingsCheckboxDropdownInitializer(cbSetting, cbLabel, cbTooltip, dropdownSetting, dropdownOptions, dropDownLabel, dropDownTooltip)
	local data =
	{
		name = cbLabel,
		tooltip = cbTooltip,
		cbSetting = cbSetting,
		cbLabel = cbLabel,
		cbTooltip = cbTooltip,
		dropdownSetting = dropdownSetting,
		dropdownOptions = dropdownOptions,
		dropDownLabel = dropDownLabel,
		dropDownTooltip = dropDownTooltip,
	};
	return Settings.CreateSettingInitializer("SettingsCheckboxDropdownControlTemplate", data);
end

SettingsCheckboxWithColorSwatchControlMixin = CreateFromMixins(SettingsControlMixin);

function SettingsCheckboxWithColorSwatchControlMixin:OnLoad()
	SettingsControlMixin.OnLoad(self);

	self.Checkbox = CreateFrame("CheckButton", nil, self, "SettingsCheckboxTemplate");
	self.Checkbox:SetPoint("LEFT", self, "CENTER", -80, 0);

	self.ColorSwatch = CreateFrame("Button", nil, self, "ColorSwatchTemplate");
	self.ColorSwatch:SetPoint("LEFT", self.Checkbox, "RIGHT", 12, -2);

	self.Tooltip:SetScript("OnMouseUp", function()
		if IsButtonEnabled(self.Checkbox) then
			self.Checkbox:Click();
		end
	end);
end

function SettingsCheckboxWithColorSwatchControlMixin:Init(initializer)
	SettingsControlMixin.Init(self, initializer);

	local setting = self:GetSetting();
	local initTooltip = GenerateClosure(InitializeSettingTooltip, initializer);

	self.Checkbox:Init(setting:GetValue(), initTooltip);
	self.cbrHandles:RegisterCallback(self.Checkbox, SettingsCheckboxMixin.Event.OnValueChanged, self.OnCheckboxValueChanged, self);

	self.ColorSwatch:SetScript("OnClick", self.data.OnSwatchClick);

	self.ColorSwatch:SetScript("OnEnter", function()
		local tooltip = GetAppropriateTooltip();
		tooltip:SetOwner(self.ColorSwatch, "ANCHOR_RIGHT");
		GameTooltip_SetTitle(tooltip, self.data.swatchTooltipTitle);
		GameTooltip_AddNormalLine(tooltip, self.data.swatchTooltipText);
		tooltip:Show();
	end);

	self.ColorSwatch:SetScript("OnLeave", function()
		GetAppropriateTooltip():Hide();
	end);

	if self.data.initialSwatchColorFn then
		self.ColorSwatch:SetColor(self.data.initialSwatchColorFn());
	end

	self:EvaluateState();
end

function SettingsCheckboxWithColorSwatchControlMixin:OnCheckboxValueChanged(value)
	local initializer = self:GetElementData();
	local setting = initializer:GetSetting();
	setting:SetValue(value);
	if value then
		PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON);
	else
		PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_OFF);
	end

	self:GetSetting():SetValue(value);
end

function SettingsCheckboxWithColorSwatchControlMixin:Release()
	self.Checkbox:Release();
	self.ColorSwatch:SetScript("OnClick", nil);
	SettingsControlMixin.Release(self);
end

function SettingsCheckboxWithColorSwatchControlMixin:SetButtonState(enabled)
	self.ColorSwatch:SetEnabled(enabled);
end

function SettingsCheckboxWithColorSwatchControlMixin:OnSettingValueChanged(setting, value)
	SettingsControlMixin.OnSettingValueChanged(self, setting, value);

	self:EvaluateState();
end

function SettingsCheckboxWithColorSwatchControlMixin:SetValue(value)
	self.Checkbox:SetChecked(value);
	if value then
		PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON);
	else
		PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_OFF);
	end
end

function SettingsCheckboxWithColorSwatchControlMixin:EvaluateState()
	SettingsListElementMixin.EvaluateState(self);
	local enabled = self:IsEnabled();

	local clickEnabled = enabled;
	if self.data.clickRequiresSet and self:GetSetting():GetValue() == self.data.invertClickRequiresSet then
		clickEnabled = false;
	end

	self:SetButtonState(clickEnabled);
	self:DisplayEnabled(enabled);
end

function CreateSettingsCheckboxWithColorSwatchInitializer(setting, checkboxTooltip, swatchClick, clickRequiresSet, invertClickRequiresSet, initialSwatchColorFn, swatchTooltipTitle, swatchTooltipText)
	local data = Settings.CreateSettingInitializerData(setting, nil, checkboxTooltip);
	data.OnSwatchClick = swatchClick;
	data.clickRequiresSet = clickRequiresSet;
	data.invertClickRequiresSet = not not invertClickRequiresSet;
	data.initialSwatchColorFn = initialSwatchColorFn;
	data.swatchTooltipTitle = swatchTooltipTitle;
	data.swatchTooltipText = swatchTooltipText;
	local initializer = Settings.CreateSettingInitializer("SettingsCheckboxWithColorSwatchControlTemplate", data);
	return initializer;
end

SettingsExpandableSectionMixin = {};

function SettingsExpandableSectionMixin:OnLoad()
	self.Button:SetScript("OnClick", function(button, buttonName, down)
		local initializer = self:GetElementData();
		local data = initializer.data;
		data.expanded = not data.expanded;

		self:SetHeight(self:CalculateHeight());

		self:OnExpandedChanged(data.expanded);
	end);
end

function SettingsExpandableSectionMixin:OnExpandedChanged(expanded)
	error("Implement OnExpandedChanged");
end

function SettingsExpandableSectionMixin:Init(initializer)
	local name = initializer:GetName();
	self.Button.Text:SetText(name);
end

SettingsExpandableSectionInitializer = CreateFromMixins(ScrollBoxFactoryInitializerMixin, SettingsSearchableElementMixin);

function SettingsExpandableSectionInitializer:GetExtent()
	error("Implement GetExtent");
end

function SettingsExpandableSectionInitializer:GetName()
	return self.data and self.data.name or "";
end

function CreateSettingsExpandableSectionInitializer(name)
	local initializer = CreateFromMixins(SettingsExpandableSectionInitializer);
	initializer:Init("SettingsExpandableSectionTemplate");
	initializer.data = {name = name};
	return initializer;
end

function CreateSettingsAddOnDisabledLabelInitializer()
	local data = {};
	return Settings.CreateElementInitializer("SettingsAddOnDisabledLabelTemplate", data);
end
